// Placeholder (Will be replaced by deploy script)
const CONFIG = {
poolId: 'REPLACE_ME',
host: 'REPLACE_ME',
region: 'us-east-1',
thing: 'garage-sensor'
};
// Initialize
AWS.config.region = CONFIG.region;
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
IdentityPoolId: CONFIG.poolId });
const client = awsIot.device({
region: CONFIG.region,
protocol: 'wss',
host: CONFIG.host,
clientId: 'web-' + Math.floor((Math.random() * 100000) + 1),
accessKeyId: AWS.config.credentials.accessKeyId,
secretKey: AWS.config.credentials.secretAccessKey,
sessionToken: AWS.config.credentials.sessionToken
});
client.on('connect', () => {
console.log('Connected');
client.subscribe(`$aws/things/${CONFIG.thing}/shadow/update/documents`);
// Get current state logic would go here
});
client.on('message', (topic, payload) => {
const data = JSON.parse(payload.toString());
const state = data.current.state.reported;
document.getElementById('status-box').innerText = state.status.toUpperCase();
document.getElementById('status-box').className = state.status;
document.getElementById('dist').innerText = state.distance;
document.getElementById('time').innerText = new Date().toLocaleTimeString();
});
