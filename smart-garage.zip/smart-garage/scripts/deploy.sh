#!/bin/bash
set -e
echo "
🔹 1. Applying Terraform..."
cd terraform
terraform init
terraform apply -auto-approve
output=$(terraform output -json)
cd ..
# Extract Variables
IOT_ENDPOINT=$(echo $output | jq -r .iot_endpoint.value)
POOL_ID=$(echo $output | jq -r .cognito_pool_id.value)
THING=$(echo $output | jq -r .thing_name.value)
BUCKET=$(echo $output | jq -r .bucket_name.value)
WIFI_SSID=$(grep wifi_ssid terraform/terraform.tfvars | cut -d'"' -f2)
WIFI_PASS=$(grep wifi_password terraform/terraform.tfvars | cut -d'"' -f2)
echo "
🔹 2. Generating ESP8266 Config..."
# Generate config.h
cat > esp8266/config.h <<EOF
#define WIFI_SSID "$WIFI_SSID"
#define WIFI_PASSWORD "$WIFI_PASS"
#define AWS_IOT_ENDPOINT "$IOT_ENDPOINT"
#define THING_NAME "$THING"
EOF
# Generate certificates.h
CERT=$(echo $output | jq -r .cert_pem.value)
KEY=$(echo $output | jq -r .key_pem.value)
cat > esp8266/certificates.h <<EOF
#include <pgmspace.h>
const char AWS_ROOT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy
rqXRfboQnoZsG4q5WTP468SQvvG5
-----END CERTIFICATE-----
)EOF";
const char client_cert_str[] PROGMEM = R"KEY(
$CERT
)KEY";
const char private_key_str[] PROGMEM = R"KEY(
$KEY
)KEY";

BearSSL::X509List cert(AWS_ROOT_CA);
BearSSL::X509List client_crt(client_cert_str);
BearSSL::PrivateKey key(private_key_str);
EOF
echo "
🔹 3. Injecting JS Config..."
sed -i "s|poolId: '.*'|poolId: '$POOL_ID'|" website/app.js
sed -i "s|host: '.*'|host: '$IOT_ENDPOINT'|" website/app.js
sed -i "s|thing: '.*'|thing: '$THING'|" website/app.js
echo "
🔹 4. Uploading to S3..."
aws s3 sync website/ s3://$BUCKET --acl public-read
echo "
✅ Done! Website URL:"
echo $output | jq -r .website_url.value
